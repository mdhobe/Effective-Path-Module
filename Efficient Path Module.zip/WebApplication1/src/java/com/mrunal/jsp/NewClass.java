package com.mrunal.jsp;
// Java program to solve Traveling Salesman Problem 
// using Branch and Bound. 
import java.util.*; 

public class NewClass 
{ 
	static int N = 21;
        public static String ans;
        public static String[] r_city;
        public static String[] city = {"Mumbai","Thane","Navi Mumbai","Lonavla","Dombivli","Bhiwandi","Panvel","Rasayani","Karjat","Matheran","Badlapur","Lavale","Hinjawadi","Kothrud","Viman Nagar","Pimpari Chinchawad","Khopoli","Hadapsar","Pune","Lavasa","Aamby Valley City"};
        //public static boolean[] cities = {true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false};
	static int final_path[] = new int[N + 1]; 

	static boolean visited[] = new boolean[N]; 
 
	public static int final_res; 

	static void copyToFinal(int curr_path[]) 
	{ 
		for (int i = 0; i < N; i++) 
			final_path[i] = curr_path[i]; 
		final_path[N] = curr_path[0]; 
	} 

	static int firstMin(int adj[][], int i) 
	{ 
		int min = Integer.MAX_VALUE; 
		for (int k = 0; k < N; k++) 
			if (adj[i][k] < min && i != k) 
				min = adj[i][k]; 
		return min; 
	} 

	static int secondMin(int adj[][], int i) 
	{ 
		int first = Integer.MAX_VALUE, second = Integer.MAX_VALUE; 
		for (int j=0; j<N; j++) 
		{ 
			if (i == j) 
				continue; 

			if (adj[i][j] <= first) 
			{ 
				second = first; 
				first = adj[i][j]; 
			} 
			else if (adj[i][j] <= second && 
					adj[i][j] != first) 
				second = adj[i][j]; 
		} 
		return second; 
	} 

	static void TSPRec(int adj[][], int curr_bound, int curr_weight, 
				int level, int curr_path[]) 
	{ 
		if (level == N) 
		{ 
			if (adj[curr_path[level - 1]][curr_path[0]] != 0) 
			{ 
				int curr_res = curr_weight + 
						adj[curr_path[level-1]][curr_path[0]]; 

				if (curr_res < final_res) 
				{ 
					copyToFinal(curr_path); 
					final_res = curr_res; 
				} 
			} 
			return; 
		} 

		for (int i = 0; i < N; i++) 
		{ 
			if (adj[curr_path[level-1]][i] != 0 && 
					visited[i] == false) 
			{ 
				int temp = curr_bound; 
				curr_weight += adj[curr_path[level - 1]][i]; 

				if (level==1) 
				curr_bound -= ((firstMin(adj, curr_path[level - 1]) + 
								firstMin(adj, i))/2); 
				else
				curr_bound -= ((secondMin(adj, curr_path[level - 1]) + 
								firstMin(adj, i))/2); 

				if (curr_bound + curr_weight < final_res) 
				{ 
					curr_path[level] = i; 
					visited[i] = true; 

					TSPRec(adj, curr_bound, curr_weight, level + 1, 
						curr_path); 
				} 

				curr_weight -= adj[curr_path[level-1]][i]; 
				curr_bound = temp; 

				Arrays.fill(visited,false); 
				for (int j = 0; j <= level - 1; j++) 
					visited[curr_path[j]] = true; 
			} 
		} 
	} 

	static void TSP(int adj[][]) 
	{ 
		int curr_path[] = new int[N + 1]; 
		int curr_bound = 0; 
		Arrays.fill(curr_path, -1); 
		Arrays.fill(visited, false); 

		for (int i = 0; i < N; i++) 
			curr_bound += (firstMin(adj, i) + 
						secondMin(adj, i)); 

		curr_bound = (curr_bound==1)? curr_bound/2 + 1 : 
									curr_bound/2; 

		visited[0] = true; 
		curr_path[0] = 0; 

		TSPRec(adj, curr_bound, 0, 1, curr_path); 
	} 
	
	public static int game(boolean[] cities) 
	{             
                final_res = Integer.MAX_VALUE;
		TSP(matrix(cities));
                cities[0] = false;
                cities[1] = false;
                cities[2] = false;
                cities[3] = false;
                cities[4] = false;
                cities[5] = false;
                cities[6] = false;
                cities[7] = false;
                cities[8] = false;
                cities[9] = false;
                cities[10] = false;
                cities[11] = false;
                cities[12] = false;
                cities[13] = false;
                cities[14] = false;
                cities[15] = false;
                cities[16] = false;
                cities[17] = false;
                cities[18] = false;
                cities[19] = false;
                cities[20] = false;
      		System.out.printf("Minimum cost : %d\n", final_res); 
		System.out.printf("Path Taken : ");
                //DrawImage.CustomPaintComponent obj = new DrawImage.CustomPaintComponent();
                ans="";
		for (int i = 0; i <= N; i++) 
		{
                        ans += r_city[final_path[i]]+",";
			//System.out.printf("%d ", final_path[i]);
                        //obj.game = ans;
		}
                return final_res;
	}
        static int[][] matrix(boolean[] cities){
            int original[][] = {{0,22,21,83,40,35,34,53,62,11,52,151,134,148,154,136,69,157,148,151,105},
                        {23,0,24,86,25,10,34,56,65,11,37,154,137,150,157,139,72,160,151,190,108},
                        {21,22,0,62,26,33,13,32,41,11,38,130,113,126,133,114,48,136,127,130,84},
                        {83,85,62,0,80,92,50,38,35,11,66,67,51,64,71,52,35,74,66,67,24},
                        {40,26,25,77,0,18,29,47,57,11,22,145,129,142,149,130,64,152,142,182,99},
                        {38,13,35,91,19,0,42,61,71,11,30,159,143,156,163,144,77,166,162,196,120},
                        {35,36,13,50,29,41,0,15,29,11,39,118,101,115,121,103,36,124,115,155,72},
                        {53,54,32,37,50,65,15,0,19,11,51,105,89,102,109,90,25,112,102,140,64},
                        {62,64,41,33,59,61,30,19,0,11,34,103,86,99,106,87,19,109,99,139,55},
                        {11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11,11},
                        {53,37,41,86,22,30,38,51,34,11,0,134,117,131,137,118,50,140,131,171,86},
                        {151,152,129,65,147,162,117,106,102,11,134,0,17,12,28,27,79,29,20,44,55},
                        {134,136,113,50,131,146,101,87,86,11,117,14,0,16,23,10,63,26,17,53,61},
                        {148,149,126,62,144,159,114,102,99,11,131,12,17,0,16,19,76,15,7,50,88},
                        {158,159,137,72,154,170,124,113,109,11,141,28,25,16,0,18,93,9,11,66,98},
                        {136,137,115,52,131,146,102,90,87,11,117,25,10,20,18,0,64,21,15,63,76},
                        {68,71,47,18,64,78,35,23,19,11,50,87,69,84,91,72,0,93,84,124,40},
                        {159,160,138,74,156,171,127,114,112,11,143,28,27,15,8,22,85,0,10,65,99},
                        {148,150,127,65,146,160,115,103,100,11,131,20,18,6,10,16,84,9,0,57,89},
                        {188,189,167,104,185,200,154,143,140,11,171,44,53,50,68,64,115,69,57,0,86},
                        {107,108,85,24,104,119,73,61,58,11,90,58,61,63,95,77,37,98,89,86,0},
                        };
        
        int counter = 0;
        for(boolean k:cities) if(k==true) counter++;
        N = counter;
        r_city = new String[counter];
        int[][] distances = new int[counter][counter];
        int index_x=0,index_y=0;
        
        for(int i=0;i<21;i++){
            if(cities[i]==true){
                for(int j=0;j<21;j++){
                    if(cities[j]==true){
                        distances[index_x][index_y] = original[i][j];
                        index_y++;
                    }
                }
                r_city[index_x] = city[i];
                index_x++;
                index_y=0;
            }
        }
        
        for(int i=0;i<counter;i++){
            for(int j=0;j<counter;j++){
                System.out.print(distances[i][j]+" ");
            }
            System.out.println();
        }
        return distances;
        }
        public static String distance(){
            return ans;
        }
} 
