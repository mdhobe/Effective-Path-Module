package com.mrunal.jsp;
import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
 
public class DrawImage {
 
    static Image image;
    public static void main(String[] args) {
 
// The image URL - change to where your image file is located!
 
        String imageURL = "C:\\Users\\Lenovo\\Desktop\\banner.jpg";
 
// This call returns immediately and pixels are loaded in the background
 
        image = Toolkit.getDefaultToolkit().getImage(imageURL);
 
// Create a frame
        Frame frame = new Frame();
 
// Add a component with a custom paint method
 
        frame.add(new CustomPaintComponent());
 
// Display the frame
 
        int frameWidth = 1291;
 
        int frameHeight = 648;
 
        frame.setSize(frameWidth, frameHeight);
 
        frame.setVisible(true);
        
        try
        {
            BufferedImage image = new BufferedImage(frameWidth, frameHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics2D = image.createGraphics();
            frame.paint(graphics2D);
            ImageIO.write(image,"jpg", new File("C:\\Users\\Lenovo\\Desktop\\map.jpg"));
        }
        catch(Exception exception)
        {
            //code
        }
        
 }
 
 /**
  * To draw on the screen, it is first necessary to subclass a Component 
  * and override its paint() method. The paint() method is automatically called 
  * by the windowing system whenever component's area needs to be repainted.
  */
  static class CustomPaintComponent extends Component {
            public String game = "Mumbai,Thane,Navi Mumbai,Lonavla,Dombivli,Bhiwandi";
            public void paint(Graphics g) {
 
  // Retrieve the graphics context; this object is used to paint shapes
 
            Graphics2D g2d = (Graphics2D)g;
            String[] citys = {"Mumbai","Thane","Navi Mumbai","Lonavla","Dombivli","Bhiwandi","Panvel","Rasayani","Karjat","Matheran","Badlapur","Lavale","Hinjawadi","Kothrud","Viman Nagar","Pimpari Chinchawad","Khopoli","Hadapsar","Pune","Lavasa","Aamby Valley City"};
            String[] city = game.split(",");
            float[] dash1 = { 5f, 0f, 5f };
            Stroke stroke = new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER,5.0f, dash1,5f);
            int[] x = {214,280,310,529,364,300,390,395,467,434,454,718,730,755,863,776,484,865,797,592,528};
            int[] y = {181,81,183,367,63,18,232,274,263,185,82,503,454,566,444,452,314,544,497,563,416};
            g2d.drawImage(image, 0, 0, this);
            g2d.setStroke(stroke);
            int a = 214, b=181;
            for(int i = 1;i < city.length;i++){
                for(int j=0;j<21;j++){
                    if(city[i].equalsIgnoreCase(citys[j])){
                        g2d.drawLine(a, b, x[j], y[j]);
                        
                        int temp1 = a;
                        a = x[i];
                        x[i] = temp1;
                        
                        int temp2 = b;
                        b = y[i];
                        y[i] = temp2;
                    }
                }
            }
            
        }
 
    }
 
}
